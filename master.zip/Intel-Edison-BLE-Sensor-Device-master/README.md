# Intel-Edison-BLE-Sensor-Device
An example application of a BLE enabled Intel Edision with a temperature sensor

The full guide can be found [here](http://docs.appiot.io/?p=8021).
